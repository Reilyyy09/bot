const { default: makeWAbotset, DisconnectReason, useSingleFileAuthState } = require('@adiwajshing/baileys');
const { Boom } = require('@hapi/boom');
const { state, loadState, saveState } = useSingleFileAuthState("./session.json")
const P = require("pino")
const logger = P();


async function connectToWhatsApp () {

    const ayaya = await makeWAbotset({
    logger: P({ level: 'silent' }),
    browser: ["Bot","Chrome","1.0.0"],
    printQRInTerminal: true,
    auth: state})
    console.log(("Done Connecting!"))
  
  ayaya.ev.on("connection.update", (update) => {
        const { connection, lastDisconnect } = update
        if (connection == "close") {
      lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut? connectToWhatsApp():
  console.log(('Sambungan Terputus...'))}
  })
  
  ayaya.ev.on('creds.update', saveState);
  
  ayaya.ev.on("messages.upsert",  async message => {
            try {
                if (!message.messages[0]) return
                let msg = message.messages[0]
                if (!msg.message) return
                        
                let m = (msg, ayaya)
                let type = Object.keys(msg.message)[0]               
                let body = msg.message?.conversation || msg.message?.imageMessage?.caption || msg.message?.videoMessage?.caption || msg.message?.extendedTextMessage?.text || msg.message?.listResponseMessage?.singleSelectReply?.selectedRowId || msg.message?.buttonsResponseMessage?.selectedButtonId || msg.message?.templateButtonReplyMessage?.selectedId || "";
                let args = body.trim().split(/ +/).slice(1)
                let q = args.join(" ")
                let command = body.slice(0).trim().split(/ +/).shift().toLowerCase()
              
                if (command) {
                    console.log(`[ MESSAGE ] dari ${message.messages[0].key.remoteJid} text: ${body}`)
                }
                switch (command) {

// ini buat case nya 
case ".mapelskola": // <---- Nama case wajib dalam "nama":
await ayaya.sendMessage(message.messages[0].key.remoteJid, { text: 'HARI : \n.senin\n.selasa\n.rabu\n.kamis\n.jumat'}) // <----- ini function buat send pesan 
break;

case ".senin": // <---- Nama case wajib dalam "nama":
await ayaya.sendMessage(message.messages[0].key.remoteJid, { text: 'Matematika' }) // <----- ini function buat send pesan 
break;

case ".selasa":
await ayaya.sendMessage(message.messages[0].key.remoteJid, { text: 'simkomdig'}) 
break;

case ".rabu":
await ayaya.sendMessage(message.messages[0].key.remoteJid, { text: 'pemograman'}) 
break;

case ".kamis":
await ayaya.sendMessage(message.messages[0].key.remoteJid, { text: 'desain grafis'}) 
break;

case ".jumat":
await ayaya.sendMessage(message.messages[0].key.remoteJid, { text: 'komjardas'}) 
break;

                    default:
         }
    } catch (err) {
        console.log( err)
    }
})
}

connectToWhatsApp()

const fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(`Update ${__filename}`)
    delete require.cache[file]
    require(file)
})